# chat2goal v1.0.0 — Microsoft Copilot Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Prompt Gallery
1. Paste `prompt_gallery.txt`, run once, click the **bookmark icon** to save.

## Copilot Studio
1. Agents -> Tools -> Add a tool -> **Add new Prompt**.
2. Paste `prompt_gallery.txt` and save.
