# chat2goal v1.0.0 — Claude Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Claude Web & Desktop (Projects)
1. New Project -> **"Add Custom Instructions"**.
2. Paste `claude_web_and_desktop/project_instructions.txt`.

## Claude Code (CLI)
1. Copy `claude_code_cli/CLAUDE.md` into your **project root**.  
   Claude Code auto-loads it at session start:
   ```
   your-project/
   └── CLAUDE.md
   ```
