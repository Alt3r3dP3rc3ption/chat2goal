# chat2goal v1.0.0 — Generic Orchestrator Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Installation
Load `chat2goal_system_prompt.md` as the system prompt in your agent:

```python
with open("chat2goal_system_prompt.md", "r") as f:
    system_prompt = f.read()
# Pass system_prompt to your agent/LLM initialization
```
