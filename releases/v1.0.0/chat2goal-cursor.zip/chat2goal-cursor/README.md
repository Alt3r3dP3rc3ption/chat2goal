# chat2goal v1.0.0 — Cursor IDE Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Installation
1. Copy `chat2goal.mdc` into your project's `.cursor/rules/` folder:
   ```
   your-project/
   └── .cursor/
       └── rules/
           └── chat2goal.mdc
   ```
2. In Cursor chat, type `/chat2goal` to invoke it.

> Note: The modern Cursor format uses `.mdc` files in `.cursor/rules/`. The legacy `.cursorrules` root file is deprecated.
