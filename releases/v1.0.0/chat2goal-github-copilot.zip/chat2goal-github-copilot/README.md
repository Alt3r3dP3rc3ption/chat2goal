# chat2goal v1.0.0 — GitHub Copilot Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Installation (VS Code & Visual Studio)
1. Copy `chat2goal.prompt.md` into `.github/prompts/`:
   ```
   your-project/
   └── .github/
       └── prompts/
           └── chat2goal.prompt.md
   ```
2. In Copilot Chat, type `/chat2goal`.
