@echo off
setlocal

echo.
echo  chat2goal Installer for Gemini CLI ^& Antigravity CLI
echo  ======================================================
echo.

:: ---------- Gemini CLI ----------
set "GEMINI_DIR=%USERPROFILE%\.gemini"
if not exist "%GEMINI_DIR%" mkdir "%GEMINI_DIR%"

copy /Y "gemini_cli\system.md" "%GEMINI_DIR%\system.md" >nul
if %errorlevel%==0 (
    echo  [OK] Gemini CLI  ^>  %GEMINI_DIR%\system.md
) else (
    echo  [FAIL] Could not copy Gemini CLI system.md
)

:: ---------- Antigravity CLI ----------
set "AGY_DIR=%USERPROFILE%\.config\antigravity\prompts"
if not exist "%AGY_DIR%" mkdir "%AGY_DIR%"

copy /Y "antigravity_cli\AGENTS.md" "%AGY_DIR%\AGENTS.md" >nul
if %errorlevel%==0 (
    echo  [OK] Antigravity  ^>  %AGY_DIR%\AGENTS.md
) else (
    echo  [FAIL] Could not copy Antigravity AGENTS.md
)

echo.
echo  Gemini CLI: run these commands before starting a session:
echo    set GEMINI_SYSTEM_MD=1
echo    gemini
echo.
echo  Antigravity: copy AGENTS.md to any project root for auto-loading,
echo  or reference it via your CLI pipeline config.
echo.
pause
endlocal
