# chat2goal Installer for Gemini CLI & Antigravity CLI
# Run with: powershell -ExecutionPolicy Bypass -File install.ps1

Write-Host ""
Write-Host " chat2goal Installer for Gemini CLI & Antigravity CLI"
Write-Host " ======================================================"
Write-Host ""

# Gemini CLI
$geminiDir = "$env:USERPROFILE\.gemini"
if (-not (Test-Path $geminiDir)) { New-Item -ItemType Directory -Path $geminiDir | Out-Null }
Copy-Item -Force "gemini_cli\system.md" "$geminiDir\system.md"
Write-Host " [OK] Gemini CLI  >  $geminiDir\system.md"

# Antigravity CLI
$agyDir = "$env:USERPROFILE\.config\antigravity\prompts"
if (-not (Test-Path $agyDir)) { New-Item -ItemType Directory -Path $agyDir -Force | Out-Null }
Copy-Item -Force "antigravity_cli\AGENTS.md" "$agyDir\AGENTS.md"
Write-Host " [OK] Antigravity  >  $agyDir\AGENTS.md"

Write-Host ""
Write-Host " Gemini CLI: run these commands before starting a session:"
Write-Host "   `$env:GEMINI_SYSTEM_MD = '1'"
Write-Host "   gemini"
Write-Host ""
Write-Host " Antigravity: copy AGENTS.md to any project root for auto-loading."
Write-Host ""
Read-Host "Press Enter to exit"
