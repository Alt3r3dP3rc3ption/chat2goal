# chat2goal v1.0.0 — Gemini & Antigravity CLI Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Quick Install (Windows 11)

Double-click **`install.bat`** to automatically copy files to the correct locations:
- Gemini CLI: `%USERPROFILE%\.gemini\system.md`
- Antigravity CLI: `%USERPROFILE%\.config\antigravity\prompts\AGENTS.md`

Or run the PowerShell version:
```
powershell -ExecutionPolicy Bypass -File install.ps1
```

## Manual Installation

### Gemini Web (Custom Gems)
1. Open Gemini -> **"Gems" -> "New Gem"**. Name it `chat2goal`.
2. Paste the contents of `gemini/gem_instructions.txt`.

### Gemini CLI (project-level)
1. Copy `gemini_cli/system.md` to your project's `.gemini/` folder:
   ```
   your-project/.gemini/system.md
   ```
2. Start a session with:
   ```
   set GEMINI_SYSTEM_MD=1
   gemini
   ```

### Antigravity CLI
1. Copy `antigravity_cli/AGENTS.md` to your project root.  
   Antigravity auto-loads it at session start.
2. Config lives at: `%USERPROFILE%\.gemini\antigravity-cli\settings.json`
