# chat2goal v1.0.0 — Perplexity Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Installation

1. In Perplexity, go to **Settings -> Skills -> Upload Skill**.
2. Upload `SKILL.md` from this folder directly.  
   Perplexity reads the YAML frontmatter automatically — no copy/paste needed.

Once uploaded, type `/chat2goal` followed by your chat transcript.
