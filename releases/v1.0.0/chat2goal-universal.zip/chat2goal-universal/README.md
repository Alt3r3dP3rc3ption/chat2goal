# chat2goal v1.0.0 — Universal Installation Package

chat2goal is a system skill that takes messy chat transcripts and compiles them into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Platform-Specific Packages

| Package | Platforms |
|---|---|
| chat2goal-perplexity.zip | Perplexity |
| chat2goal-claude.zip | Claude Web, Claude Desktop, Claude Code CLI |
| chat2goal-chatgpt.zip | ChatGPT Custom GPTs |
| chat2goal-gemini.zip | Gemini Custom Gems, Gemini CLI, Antigravity CLI |
| chat2goal-cursor.zip | Cursor IDE |
| chat2goal-github-copilot.zip | GitHub Copilot (VS Code & Visual Studio) |
| chat2goal-microsoft.zip | Microsoft Copilot, Copilot Studio |
| chat2goal-codex.zip | OpenAI Codex / API |
| chat2goal-generic.zip | Generic Python/Node.js Orchestrators |

## Installation by Platform

**Perplexity**
1. In Perplexity, go to Settings -> Skills -> Upload Skill.
2. Upload `perplexity/SKILL.md` directly. Perplexity reads the YAML frontmatter automatically.

**Gemini CLI & Antigravity CLI (Windows 11)**
1. Extract the zip, open `gemini_cli+antigravity/`, and double-click `install.bat`.
   - Installs `system.md` to `%USERPROFILE%\.gemini\`
   - Installs `AGENTS.md` to `%USERPROFILE%\.config\antigravity\prompts\`
2. For Gemini CLI, set `GEMINI_SYSTEM_MD=1` before starting a session.

**Gemini (Web / Custom Gems)**
1. Open Gemini -> "Gems" -> "New Gem". Name it `chat2goal`.
2. Paste the contents of `gemini/gem_instructions.txt`.

**ChatGPT (Custom GPTs)**
1. ChatGPT -> Explore -> Create a GPT -> Configure.
2. Paste `chatgpt/custom_gpt_instructions.txt` into the Instructions box.

**Claude (Web & Desktop Projects)**
1. New Project -> Add Custom Instructions.
2. Paste `claude_web_and_desktop/project_instructions.txt`.

**Claude Code (CLI)**
1. Copy `claude_code_cli/CLAUDE.md` into your project root.

**Cursor IDE**
1. Copy `cursor_ide/chat2goal.mdc` into `.cursor/rules/` in your project root.
2. Invoke with `/chat2goal` in Cursor chat.

**GitHub Copilot**
1. Copy `github_copilot/chat2goal.prompt.md` into `.github/prompts/`.
2. Invoke with `/chat2goal` in Copilot Chat.

**Microsoft Copilot**
1. Prompt Gallery: Paste `microsoft_copilot/prompt_gallery.txt`, run once, bookmark it.
2. Copilot Studio: Agents -> Tools -> Add new Prompt.

**OpenAI Codex**
1. Inject `openai_codex/system_message.txt` into the `role: "system"` payload.

**Generic Orchestrators**
1. Use `generic_orchestrator/chat2goal_system_prompt.md` in your agent definitions.
