# chat2goal v1.0.0 — ChatGPT Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Custom GPT
1. ChatGPT -> **"Explore" -> "Create a GPT" -> "Configure"**.
2. Paste `custom_gpt_instructions.txt` into the **"Instructions"** box and save.
