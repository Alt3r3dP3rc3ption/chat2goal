# chat2goal v1.0.0 — OpenAI Codex / API Installation

chat2goal compiles messy chat transcripts into rigorous, executable /goal prompts for agentic models like Anthropic's Fable 5.

Invoke with: `/chat2goal`

## Installation
Inject `system_message.txt` into the `role: "system"` payload:

```python
import openai

with open("system_message.txt", "r") as f:
    system_prompt = f.read()

response = openai.chat.completions.create(
    model="codex-mini-latest",
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "{chat_transcript}"}
    ]
)
```
